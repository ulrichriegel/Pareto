#' Example data: Atachment Points
#'
"Example1_AP"

#' Example data: Expected Losses
#'
#'
"Example1_EL"


#### ' @useDynLib glrm
#### ' @importFrom Rcpp sourceCpp
# NULL

